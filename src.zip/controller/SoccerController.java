package controller;

public class SoccerController {
	public void menu() {
		System.out.println("축구 통계");
	}
}
